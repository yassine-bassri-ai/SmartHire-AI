import { useParams, useNavigate } from 'react-router-dom';
import {
  Box, Grid2 as Grid, CardContent, Typography, Divider, Chip, Stack, Button,
} from '@mui/material';
import ArrowBackRoundedIcon from '@mui/icons-material/ArrowBackRounded';
import WorkOutlineRoundedIcon from '@mui/icons-material/WorkOutlineRounded';
import BusinessRoundedIcon from '@mui/icons-material/BusinessRounded';
import LanguageRoundedIcon from '@mui/icons-material/LanguageRounded';
import WorkHistoryRoundedIcon from '@mui/icons-material/WorkHistoryRounded';
import CodeRoundedIcon from '@mui/icons-material/CodeRounded';
import SchoolRoundedIcon from '@mui/icons-material/SchoolRounded';
import ArticleRoundedIcon from '@mui/icons-material/ArticleRounded';
import PageHeader, { CardWrapper, CardTitle } from '@/components/PageHeader';
import InfoRow from '@/components/cards/InfoRow';
import ChipList from '@/components/common/ChipList';
import RawText from '@/components/common/RawText';
import EmptyData from '@/components/layout/EmptyData';
import { useJob } from '@/hooks/useJob';

function decodeDescription(desc?: string): string {
  if (!desc) return '';
  // Backend may store a JSON-stringified dict inside description.
  try {
    const parsed = JSON.parse(desc);
    if (parsed && typeof parsed === 'object') {
      return parsed.cleaned_text ?? parsed.processed_text ?? desc;
    }
  } catch {
    // not JSON — return as-is
  }
  return desc;
}

export default function JobDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const jobId = id ? Number(id) : undefined;
  const { data: job, isLoading, isError } = useJob(jobId);

  return (
    <Box>
      <PageHeader
        title="Job Details"
        subtitle={`Complete job description for job #${id ?? '—'}`}
        icon={<WorkOutlineRoundedIcon />}
        action={
          <Button variant="outlined" startIcon={<ArrowBackRoundedIcon />} onClick={() => navigate('/jobs')}>
            Back
          </Button>
        }
      />

      {isLoading ? (
        <CardWrapper><CardContent><Box sx={{ p: 4 }}><EmptyData title="Loading job…" description="Fetching parsed job data from the backend." icon={<WorkOutlineRoundedIcon />} /></Box></CardContent></CardWrapper>
      ) : isError || !job ? (
        <CardWrapper><CardContent><EmptyData title="Job not found" description="The job could not be loaded. It may have been removed or the backend is offline." /></CardContent></CardWrapper>
      ) : (
        <Grid container spacing={3}>
          {/* Summary */}
          <Grid size={{ xs: 12, lg: 4 }}>
            <CardWrapper sx={{ height: '100%' }}>
              <CardTitle title="Job Overview" action={<Chip label={`#${job.id}`} size="small" />} />
              <CardContent sx={{ pt: 1 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.5, mb: 2 }}>
                  <Box sx={{ width: 56, height: 56, borderRadius: 3, background: 'linear-gradient(135deg,#14B8A6,#2563EB)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <WorkOutlineRoundedIcon sx={{ color: '#fff', fontSize: 28 }} />
                  </Box>
                  <Box sx={{ minWidth: 0 }}>
                    <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>{job.job_title ?? job.title}</Typography>
                    <Typography variant="caption" sx={{ color: 'text.secondary' }}>{job.company}</Typography>
                  </Box>
                </Box>
                <Divider />
                <InfoRow icon={<BusinessRoundedIcon fontSize="small" />} label="Company">
                  <Typography variant="body2">{job.company ?? '—'}</Typography>
                </InfoRow>
                <Divider />
                <InfoRow icon={<LanguageRoundedIcon fontSize="small" />} label="Language">
                  <Typography variant="body2">{job.language ?? '—'}</Typography>
                </InfoRow>
                <Divider />
                <InfoRow icon={<WorkHistoryRoundedIcon fontSize="small" />} label="Experience Required">
                  <Typography variant="body2" sx={{ fontWeight: 600 }}>{job.experience_required ?? job.experience_years ?? 0} years</Typography>
                </InfoRow>
                {job.job_id && (
                  <>
                    <Divider />
                    <InfoRow icon={<ArticleRoundedIcon fontSize="small" />} label="Job Code">
                      <Typography variant="body2">{job.job_id}</Typography>
                    </InfoRow>
                  </>
                )}
              </CardContent>
            </CardWrapper>
          </Grid>

          {/* Requirements */}
          <Grid size={{ xs: 12, lg: 8 }}>
            <CardWrapper>
              <CardTitle title="Job Requirements" />
              <CardContent sx={{ pt: 1 }}>
                <InfoRow icon={<CodeRoundedIcon fontSize="small" />} label="Required Skills">
                  <ChipList items={job.skills} color="secondary" />
                </InfoRow>
                <Divider />
                <InfoRow icon={<SchoolRoundedIcon fontSize="small" />} label="Education">
                  <ChipList items={job.education} color="primary" />
                </InfoRow>
                <Divider />
                <InfoRow icon={<LanguageRoundedIcon fontSize="small" />} label="Languages">
                  <ChipList items={job.languages} color="warning" />
                </InfoRow>
                <Divider />
                <InfoRow icon={<ArticleRoundedIcon fontSize="small" />} label="Job Description">
                  <RawText text={decodeDescription(job.description ?? job.raw_text)} maxHeight={460} />
                </InfoRow>
              </CardContent>
            </CardWrapper>
          </Grid>
        </Grid>
      )}
    </Box>
  );
}
