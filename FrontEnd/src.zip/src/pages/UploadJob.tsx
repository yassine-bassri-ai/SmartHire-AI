import { useState } from 'react';
import { Box, Grid2 as Grid, CardContent, Typography, Stack, Divider } from '@mui/material';
import { motion } from 'framer-motion';
import WorkOutlineRoundedIcon from '@mui/icons-material/WorkOutlineRounded';
import CodeRoundedIcon from '@mui/icons-material/CodeRounded';
import BusinessRoundedIcon from '@mui/icons-material/BusinessRounded';
import LanguageRoundedIcon from '@mui/icons-material/LanguageRounded';
import WorkHistoryRoundedIcon from '@mui/icons-material/WorkHistoryRounded';
import ArticleRoundedIcon from '@mui/icons-material/ArticleRounded';
import PageHeader, { CardWrapper, CardTitle } from '@/components/PageHeader';
import FileDropzone from '@/components/FileDropzone';
import InfoRow from '@/components/cards/InfoRow';
import ChipList from '@/components/common/ChipList';
import RawText from '@/components/common/RawText';
import EmptyData from '@/components/layout/EmptyData';
import UploadProgress from '@/components/upload/UploadProgress';
import { useUploadJob } from '@/hooks/useJob';
import type { Job } from '@/utils/types';
import toast from 'react-hot-toast';

export default function UploadJob() {
  const [progress, setProgress] = useState(0);
  const [filename, setFilename] = useState<string | null>(null);
  const [parsed, setParsed] = useState<Job | null>(null);
  const uploadMutation = useUploadJob();

  const handleUpload = async (file: File) => {
    setProgress(0);
    setParsed(null);
    try {
      const result = await uploadMutation.mutateAsync({
        file,
        onProgress: (pct) => setProgress(pct),
      });
      setParsed(result.job);
      setFilename(file.name);
      toast.success('Job description uploaded & parsed!');
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Upload failed');
    }
  };

  const description = parsed?.description ?? parsed?.raw_text ?? '';

  return (
    <Box>
      <PageHeader
        title="Upload Job"
        subtitle="Upload a JSON job description to extract role requirements"
        icon={<WorkOutlineRoundedIcon />}
      />

      <Grid container spacing={3}>
        <Grid size={{ xs: 12, md: 6 }}>
          <CardWrapper>
            <CardTitle title="Drop your job JSON" />
            <CardContent sx={{ pt: 1 }}>
              <FileDropzone
                onFileSelected={handleUpload}
                accept={{ 'application/json': ['.json'] }}
                title="Drag & drop your job JSON file"
                subtitle="Only JSON files are supported · max 5MB"
                icon={<CodeRoundedIcon sx={{ fontSize: 36 }} />}
                uploading={uploadMutation.isPending}
                progress={progress}
                uploadedFile={filename}
                onClear={() => { setFilename(null); setParsed(null); }}
                buttonText="Upload Job"
              />
              <UploadProgress uploading={uploadMutation.isPending} progress={progress} label="Parsing job…" />
            </CardContent>
          </CardWrapper>
        </Grid>

        <Grid size={{ xs: 12, md: 6 }}>
          <CardWrapper sx={{ height: '100%' }}>
            <CardTitle title="Parsed Job Preview" />
            <CardContent sx={{ pt: 1 }}>
              {!parsed ? (
                <EmptyData
                  title="No job parsed yet"
                  description="Upload a JSON job description to see extracted title, company, language, experience and required skills."
                  icon={<WorkOutlineRoundedIcon sx={{ fontSize: 40 }} />}
                />
              ) : (
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
                  <InfoRow icon={<WorkOutlineRoundedIcon fontSize="small" />} label="Job Title">
                    <Typography variant="body2" sx={{ fontWeight: 600 }}>{parsed.job_title ?? parsed.title ?? '—'}</Typography>
                  </InfoRow>
                  <Divider />
                  <InfoRow icon={<BusinessRoundedIcon fontSize="small" />} label="Company">
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>{parsed.company ?? '—'}</Typography>
                  </InfoRow>
                  <Divider />
                  <InfoRow icon={<LanguageRoundedIcon fontSize="small" />} label="Language">
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>{parsed.language ?? '—'}</Typography>
                  </InfoRow>
                  <Divider />
                  <InfoRow icon={<WorkHistoryRoundedIcon fontSize="small" />} label="Experience Required">
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>{parsed.experience_required ?? parsed.experience_years ?? 0} years</Typography>
                  </InfoRow>
                  <Divider />
                  <InfoRow icon={<CodeRoundedIcon fontSize="small" />} label="Required Skills">
                    <ChipList items={parsed.skills} color="secondary" />
                  </InfoRow>
                  <Divider />
                  <InfoRow icon={<ArticleRoundedIcon fontSize="small" />} label="Education">
                    <ChipList items={parsed.education} color="secondary" />
                  </InfoRow>
                  <Divider />
                  <InfoRow icon={<LanguageRoundedIcon fontSize="small" />} label="Languages">
                    <ChipList items={parsed.languages} color="secondary" />
                  </InfoRow>
                  <Divider />
                  <InfoRow icon={<ArticleRoundedIcon fontSize="small" />} label="Description">
                    <RawText text={description} maxHeight={220} />
                  </InfoRow>
                </motion.div>
              )}
            </CardContent>
          </CardWrapper>
        </Grid>
      </Grid>
    </Box>
  );
}
