import { Box, Grid2 as Grid, Typography, Card, CardContent, Stack, Chip } from '@mui/material';
import { motion } from 'framer-motion';
import DescriptionRoundedIcon from '@mui/icons-material/DescriptionRounded';
import WorkOutlineRoundedIcon from '@mui/icons-material/WorkOutlineRounded';
import InsightsRoundedIcon from '@mui/icons-material/InsightsRounded';
import EmojiEventsRoundedIcon from '@mui/icons-material/EmojiEventsRounded';
import PageHeader, { CardWrapper, CardTitle } from '@/components/PageHeader';
import StatCard from '@/components/StatCard';
import { StatCardSkeleton, ChartSkeleton, TableSkeleton } from '@/components/Skeletons';
import TrendChart from '@/components/charts/TrendChart';
import DonutChart from '@/components/charts/DonutChart';
import BarsChart from '@/components/charts/BarsChart';
import EmptyData from '@/components/layout/EmptyData';
import { useDashboard } from '@/hooks/useDashboard';
import { useResumes } from '@/hooks/useResume';
import { useJobs } from '@/hooks/useJob';
import { usePredictions } from '@/hooks/usePrediction';
import { useMemo } from 'react';

const CHART_COLORS = ['#2563EB', '#14B8A6', '#F59E0B', '#0EA5E9', '#16A34A', '#DC2626', '#8B5CF6', '#EC4899'];

export default function Dashboard() {
  const { data: dashboard, isLoading: loadingDashboard } = useDashboard();
  const { data: resumes = [], isLoading: loadingResumes } = useResumes();
  const { data: jobs = [], isLoading: loadingJobs } = useJobs();

  const totalResumes = dashboard?.total_resumes ?? resumes.length;
  const totalJobs = dashboard?.total_jobs ?? jobs.length;
  const totalPredictions = dashboard?.total_predictions ?? 0;
  const averageScore = dashboard?.average_score ?? 0;
  const loading = loadingDashboard || loadingResumes || loadingJobs;

  // Build charts from real data when dashboard.charts is absent.
  const charts = useMemo(() => {
    if (dashboard?.charts) return dashboard.charts;

    const skillsMap = new Map<string, number>();
    resumes.forEach((r) => (r.skills ?? []).forEach((s) => skillsMap.set(s, (skillsMap.get(s) ?? 0) + 1)));
    const topSkills = [...skillsMap.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8);

    const langMap = new Map<string, number>();
    resumes.forEach((r) => langMap.set(r.language ?? 'Unknown', (langMap.get(r.language ?? 'Unknown') ?? 0) + 1));

    return {
      monthly: [],
      score_distribution: [],
      languages_distribution: [...langMap.entries()].map(([name, value]) => ({ name, value })),
      skills_distribution: topSkills.map(([name, value]) => ({ name, value })),
      prediction_distribution: [],
    };
  }, [dashboard, resumes]);

  // Best candidates fallback from resume list.
  const bestCandidates = dashboard?.best_candidates ?? [];
  const recentResumes = resumes.slice(0, 5);
  const recentJobs = jobs.slice(0, 5);

  return (
    <Box>
      <PageHeader
        title="Dashboard"
        subtitle="Overview of your recruitment intelligence platform"
        icon={<InsightsRoundedIcon />}
      />

      {/* Stat cards */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        {loading ? (
          Array.from({ length: 4 }).map((_, i) => (
            <Grid size={{ xs: 12, sm: 6, lg: 3 }} key={i}><StatCardSkeleton /></Grid>
          ))
        ) : (
          <>
            <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
              <StatCard title="Total Resumes" value={totalResumes} icon={<DescriptionRoundedIcon />} color="primary" delay={0} />
            </Grid>
            <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
              <StatCard title="Total Jobs" value={totalJobs} icon={<WorkOutlineRoundedIcon />} color="secondary" delay={0.05} />
            </Grid>
            <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
              <StatCard title="Predictions" value={totalPredictions} icon={<InsightsRoundedIcon />} color="accent" delay={0.1} />
            </Grid>
            <Grid size={{ xs: 12, sm: 6, lg: 3 }}>
              <StatCard title="Average Score" value={Math.round(averageScore)} suffix="%" icon={<EmojiEventsRoundedIcon />} color="success" delay={0.15} />
            </Grid>
          </>
        )}
      </Grid>

      {/* Charts row */}
      <Grid container spacing={3} sx={{ mb: 3 }}>
        <Grid size={{ xs: 12, lg: 8 }}>
          {loading ? (
            <ChartSkeleton />
          ) : (
            <CardWrapper>
              <CardTitle title="Skills Distribution" />
              <CardContent sx={{ pt: 1 }}>
                {charts.skills_distribution.length > 0 ? (
                  <BarsChart data={charts.skills_distribution.map((d, i) => ({ ...d, color: CHART_COLORS[i % CHART_COLORS.length] }))} height={300} />
                ) : (
                  <EmptyData title="No skills data yet" description="Upload resumes to see skill distribution here." />
                )}
              </CardContent>
            </CardWrapper>
          )}
        </Grid>
        <Grid size={{ xs: 12, lg: 4 }}>
          {loading ? (
            <ChartSkeleton />
          ) : (
            <CardWrapper>
              <CardTitle title="Languages Distribution" />
              <CardContent sx={{ pt: 1 }}>
                {charts.languages_distribution.length > 0 ? (
                  <DonutChart data={charts.languages_distribution.map((d, i) => ({ ...d, color: CHART_COLORS[i % CHART_COLORS.length] }))} height={300} />
                ) : (
                  <EmptyData title="No language data yet" description="Upload resumes to see language distribution." />
                )}
              </CardContent>
            </CardWrapper>
          )}
        </Grid>
      </Grid>

      {/* Bottom row */}
      <Grid container spacing={3}>
        <Grid size={{ xs: 12, lg: 4 }}>
          {loading ? (
            <TableSkeleton rows={4} cols={2} />
          ) : (
            <CardWrapper sx={{ height: '100%' }}>
              <CardTitle title="Best Candidates" />
              <CardContent sx={{ pt: 1 }}>
                {bestCandidates.length > 0 ? (
                  <Stack spacing={1.5}>
                    {bestCandidates.map((c, i) => (
                      <Box key={c.id} sx={{ display: 'flex', alignItems: 'center', gap: 1.5, p: 1.25, borderRadius: 2, '&:hover': { bgcolor: 'action.hover' } }}>
                        <Chip label={i + 1} size="small" sx={{ fontWeight: 700, bgcolor: i === 0 ? 'rgba(245,158,11,0.14)' : 'action.hover' }} />
                        <Box sx={{ flex: 1, minWidth: 0 }}>
                          <Typography variant="body2" sx={{ fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{c.filename}</Typography>
                          {c.best_match && <Typography variant="caption" sx={{ color: 'text.secondary' }}>{c.best_match}</Typography>}
                        </Box>
                        <Typography variant="body2" sx={{ fontWeight: 700, color: 'primary.main' }}>{Math.round(c.score)}%</Typography>
                      </Box>
                    ))}
                  </Stack>
                ) : (
                  <EmptyData title="No candidates ranked yet" description="Run predictions to rank your best candidates." />
                )}
              </CardContent>
            </CardWrapper>
          )}
        </Grid>

        <Grid size={{ xs: 12, lg: 4 }}>
          <CardWrapper sx={{ height: '100%' }}>
            <CardTitle title="Recent Resumes" />
            <CardContent sx={{ pt: 1 }}>
              {recentResumes.length > 0 ? (
                <Stack spacing={1}>
                  {recentResumes.map((r) => (
                    <Box key={r.id} component={motion.div} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} sx={{ display: 'flex', alignItems: 'center', gap: 1.5, p: 1.25, borderRadius: 2, '&:hover': { bgcolor: 'action.hover' } }}>
                      <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: 'primary.main', flexShrink: 0 }} />
                      <Box sx={{ flex: 1, minWidth: 0 }}>
                        <Typography variant="body2" sx={{ fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.filename}</Typography>
                      </Box>
                      <Chip label={`${r.experience_years ?? 0}y`} size="small" variant="outlined" />
                    </Box>
                  ))}
                </Stack>
              ) : (
                <EmptyData title="No resumes uploaded" description="Upload resumes to see them here." />
              )}
            </CardContent>
          </CardWrapper>
        </Grid>

        <Grid size={{ xs: 12, lg: 4 }}>
          <CardWrapper sx={{ height: '100%' }}>
            <CardTitle title="Recent Jobs" />
            <CardContent sx={{ pt: 1 }}>
              {recentJobs.length > 0 ? (
                <Stack spacing={1}>
                  {recentJobs.map((j) => (
                    <Box key={j.id} component={motion.div} initial={{ opacity: 0, x: 10 }} animate={{ opacity: 1, x: 0 }} sx={{ display: 'flex', alignItems: 'center', gap: 1.5, p: 1.25, borderRadius: 2, '&:hover': { bgcolor: 'action.hover' } }}>
                      <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: 'secondary.main', flexShrink: 0 }} />
                      <Box sx={{ flex: 1, minWidth: 0 }}>
                        <Typography variant="body2" sx={{ fontWeight: 500, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{j.job_title}</Typography>
                        <Typography variant="caption" sx={{ color: 'text.secondary' }}>{j.company}</Typography>
                      </Box>
                    </Box>
                  ))}
                </Stack>
              ) : (
                <EmptyData title="No jobs uploaded" description="Upload job descriptions to see them here." />
              )}
            </CardContent>
          </CardWrapper>
        </Grid>
      </Grid>
    </Box>
  );
}
