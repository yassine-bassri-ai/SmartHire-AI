import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box, Typography, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, TablePagination,
  TextField, MenuItem, FormControl, InputLabel, Select, Chip, Stack, IconButton, Tooltip,
} from '@mui/material';
import { motion } from 'framer-motion';
import PersonSearchRoundedIcon from '@mui/icons-material/PersonSearchRounded';
import SearchRoundedIcon from '@mui/icons-material/SearchRounded';
import VisibilityRoundedIcon from '@mui/icons-material/VisibilityRounded';
import ArrowUpwardRoundedIcon from '@mui/icons-material/ArrowUpwardRounded';
import ArrowDownwardRoundedIcon from '@mui/icons-material/ArrowDownwardRounded';
import PageHeader, { CardWrapper, CardTitle } from '@/components/PageHeader';
import ScoreBadge, { scoreColor } from '@/components/common/ScoreBadge';
import EmptyData from '@/components/layout/EmptyData';
import { TableSkeleton } from '@/components/Skeletons';
import { useResumes } from '@/hooks/useResume';
import { usePredictions } from '@/hooks/usePrediction';
import type { Prediction } from '@/utils/types';

interface RankedCandidate {
  resumeId: number;
  filename: string;
  bestMatch: string;
  score: number;
  probability: number;
  jobId: number | string;
}

export default function CandidateRanking() {
  const navigate = useNavigate();
  const { data: resumes = [], isLoading: loadingResumes } = useResumes();

  const [search, setSearch] = useState('');
  const [minScore, setMinScore] = useState('');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(8);

  // Gather top prediction per resume to build a ranking table.
  // We use usePredictions for the first resume only as a primary source when available;
  // otherwise we fall back to aggregate from resumes.
  const firstId = resumes[0]?.id;
  const { data: firstPredictions = [] } = usePredictions(firstId);

  const candidates: RankedCandidate[] = useMemo(() => {
    const ranked: RankedCandidate[] = [];
    resumes.forEach((r) => {
      const filename = r.filename ?? `Resume #${r.id}`;
      // If we have predictions for the first resume, seed scores from them as a proxy.
      if (r.id === firstId && firstPredictions.length > 0) {
        firstPredictions.forEach((p: Prediction) => {
          ranked.push({
            resumeId: r.id,
            filename: `${filename} → ${p.job_title}`,
            bestMatch: p.job_title,
            score: Math.round(p.score ?? p.probability * 100),
            probability: p.probability,
            jobId: p.job_id,
          });
        });
        return;
      }
      // Fallback: rank resumes by experience as a neutral proxy until predictions run.
      ranked.push({
        resumeId: r.id,
        filename,
        bestMatch: 'Awaiting prediction',
        score: Math.min(100, Math.max(0, (r.experience_years ?? 0) * 10)),
        probability: 0,
        jobId: 0,
      });
    });
    return ranked;
  }, [resumes, firstId, firstPredictions]);

  const filtered = candidates.filter((c) => {
    const q = search.toLowerCase();
    const matchSearch = !q || c.filename.toLowerCase().includes(q) || c.bestMatch.toLowerCase().includes(q);
    const matchScore = !minScore || c.score >= Number(minScore);
    return matchSearch && matchScore;
  });

  const sorted = [...filtered].sort((a, b) => (sortDir === 'desc' ? b.score - a.score : a.score - b.score));
  const paged = sorted.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  return (
    <Box>
      <PageHeader
        title="Candidate Ranking"
        subtitle="Sortable, filterable ranking of candidates by AI match score"
        icon={<PersonSearchRoundedIcon />}
      />

      <CardWrapper>
        <CardTitle title="All Candidates" />
        <Box sx={{ px: 2.5, pb: 1 }}>
          <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} alignItems={{ md: 'center' }}>
            <TextField
              size="small"
              placeholder="Search candidates…"
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(0); }}
              sx={{ flex: 1, minWidth: 200 }}
              slotProps={{ input: { startAdornment: <SearchRoundedIcon sx={{ color: 'text.secondary', fontSize: 20, mr: 1 }} /> } }}
            />
            <FormControl size="small" sx={{ minWidth: 150 }}>
              <InputLabel>Min Score</InputLabel>
              <Select value={minScore} label="Min Score" onChange={(e) => { setMinScore(e.target.value); setPage(0); }}>
                <MenuItem value="">Any</MenuItem>
                <MenuItem value="50">50+</MenuItem>
                <MenuItem value="70">70+</MenuItem>
                <MenuItem value="85">85+</MenuItem>
              </Select>
            </FormControl>
            <Tooltip title={sortDir === 'desc' ? 'Sort descending' : 'Sort ascending'}>
              <IconButton size="small" onClick={() => setSortDir((d) => (d === 'desc' ? 'asc' : 'desc'))}>
                {sortDir === 'desc' ? <ArrowDownwardRoundedIcon /> : <ArrowUpwardRoundedIcon />}
              </IconButton>
            </Tooltip>
          </Stack>
        </Box>

        {loadingResumes ? (
          <Box sx={{ p: 2 }}><TableSkeleton rows={6} cols={5} /></Box>
        ) : paged.length === 0 ? (
          <EmptyData title="No candidates ranked" description="Upload resumes and run predictions to see rankings here." />
        ) : (
          <TableContainer>
            <Table size="small">
              <TableHead>
                <TableRow>
                  <TableCell>Rank</TableCell>
                  <TableCell>Candidate / Job</TableCell>
                  <TableCell>Best Match</TableCell>
                  <TableCell>Probability</TableCell>
                  <TableCell align="right">Score</TableCell>
                  <TableCell align="center">Action</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {paged.map((c, i) => (
                  <TableRow
                    key={`${c.resumeId}-${c.jobId}-${i}`}
                    component={motion.tr}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.04 }}
                    hover
                  >
                    <TableCell>
                      <Chip
                        label={i + 1}
                        size="small"
                        sx={{ fontWeight: 700, bgcolor: i === 0 ? 'rgba(245,158,11,0.14)' : 'action.hover', color: i === 0 ? 'accent.main' : 'text.primary' }}
                      />
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" sx={{ fontWeight: 600 }}>{c.filename}</Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" sx={{ color: 'text.secondary' }}>{c.bestMatch}</Typography>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2" sx={{ fontWeight: 700, color: scoreColor(c.score) }}>
                        {c.probability > 0 ? `${(c.probability * 100).toFixed(1)}%` : '—'}
                      </Typography>
                    </TableCell>
                    <TableCell align="right"><ScoreBadge score={c.score} /></TableCell>
                    <TableCell align="center">
                      <Tooltip title="View resume">
                        <IconButton size="small" onClick={() => navigate(`/resumes/${c.resumeId}`)}>
                          <VisibilityRoundedIcon fontSize="small" />
                        </IconButton>
                      </Tooltip>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        )}

        {!loadingResumes && sorted.length > 0 && (
          <TablePagination
            component="div"
            count={sorted.length}
            page={page}
            onPageChange={(_, p) => setPage(p)}
            rowsPerPage={rowsPerPage}
            onRowsPerPageChange={(e) => { setRowsPerPage(parseInt(e.target.value, 10)); setPage(0); }}
            rowsPerPageOptions={[8, 16, 24]}
          />
        )}
      </CardWrapper>
    </Box>
  );
}
