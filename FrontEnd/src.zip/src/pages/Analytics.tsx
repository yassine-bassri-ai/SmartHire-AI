import { useMemo } from 'react';
import { Box, Grid2 as Grid, CardContent, Typography } from '@mui/material';
import InsightsRoundedIcon from '@mui/icons-material/InsightsRounded';
import PageHeader, { CardWrapper, CardTitle } from '@/components/PageHeader';
import DonutChart from '@/components/charts/DonutChart';
import BarsChart from '@/components/charts/BarsChart';
import TrendChart from '@/components/charts/TrendChart';
import EmptyData from '@/components/layout/EmptyData';
import { ChartSkeleton } from '@/components/Skeletons';
import { useDashboard } from '@/hooks/useDashboard';
import { useResumes } from '@/hooks/useResume';
import { useJobs } from '@/hooks/useJob';

const PALETTE = ['#2563EB', '#14B8A6', '#F59E0B', '#0EA5E9', '#16A34A', '#DC2626', '#8B5CF6', '#EC4899'];

export default function Analytics() {
  const { data: dashboard, isLoading: loadingDash } = useDashboard();
  const { data: resumes = [], isLoading: loadingResumes } = useResumes();
  const { data: jobs = [], isLoading: loadingJobs } = useJobs();
  const loading = loadingDash || loadingResumes || loadingJobs;

  const charts = useMemo(() => {
    if (dashboard?.charts) return dashboard.charts;

    const skillsMap = new Map<string, number>();
    resumes.forEach((r) => (r.skills ?? []).forEach((s) => skillsMap.set(s, (skillsMap.get(s) ?? 0) + 1)));
    const topSkills = [...skillsMap.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8);

    const langMap = new Map<string, number>();
    resumes.forEach((r) => langMap.set(r.language ?? 'Unknown', (langMap.get(r.language ?? 'Unknown') ?? 0) + 1));

    const scoreBins = [
      { name: '0-49%', value: resumes.filter((r) => r.experience_years !== undefined && r.experience_years < 3).length },
      { name: '50-69%', value: resumes.filter((r) => r.experience_years !== undefined && r.experience_years >= 3 && r.experience_years < 6).length },
      { name: '70-84%', value: resumes.filter((r) => r.experience_years !== undefined && r.experience_years >= 6 && r.experience_years < 9).length },
      { name: '85-100%', value: resumes.filter((r) => r.experience_years !== undefined && r.experience_years >= 9).length },
    ];

    return {
      monthly: [],
      score_distribution: scoreBins,
      languages_distribution: [...langMap.entries()].map(([name, value]) => ({ name, value })),
      skills_distribution: topSkills.map(([name, value]) => ({ name, value })),
      prediction_distribution: [],
    };
  }, [dashboard, resumes]);

  const scoreDist = (charts.score_distribution ?? []).map((d, i) => ({ ...d, color: PALETTE[i % PALETTE.length] }));
  const langDist = (charts.languages_distribution ?? []).map((d, i) => ({ ...d, color: PALETTE[i % PALETTE.length] }));
  const skillsDist = (charts.skills_distribution ?? []).map((d, i) => ({ ...d, color: PALETTE[i % PALETTE.length] }));
  const predDist = (charts.prediction_distribution ?? []).map((d, i) => ({ ...d, color: PALETTE[i % PALETTE.length] }));

  return (
    <Box>
      <PageHeader
        title="Analytics"
        subtitle="Score distribution, languages, skills and prediction insights"
        icon={<InsightsRoundedIcon />}
      />

      <Grid container spacing={3}>
        {/* Score distribution */}
        <Grid size={{ xs: 12, lg: 6 }}>
          {loading ? <ChartSkeleton /> : (
            <CardWrapper>
              <CardTitle title="Score Distribution" />
              <CardContent sx={{ pt: 1 }}>
                {scoreDist.length > 0 ? (
                  <DonutChart data={scoreDist} height={300} />
                ) : (
                  <EmptyData title="No score data" description="Run predictions to build score distribution." />
                )}
              </CardContent>
            </CardWrapper>
          )}
        </Grid>

        {/* Languages distribution */}
        <Grid size={{ xs: 12, lg: 6 }}>
          {loading ? <ChartSkeleton /> : (
            <CardWrapper>
              <CardTitle title="Languages Distribution" />
              <CardContent sx={{ pt: 1 }}>
                {langDist.length > 0 ? (
                  <DonutChart data={langDist} height={300} />
                ) : (
                  <EmptyData title="No language data" description="Upload resumes to build language distribution." />
                )}
              </CardContent>
            </CardWrapper>
          )}
        </Grid>

        {/* Skills distribution */}
        <Grid size={{ xs: 12, lg: 6 }}>
          {loading ? <ChartSkeleton /> : (
            <CardWrapper>
              <CardTitle title="Most Common Skills" />
              <CardContent sx={{ pt: 1 }}>
                {skillsDist.length > 0 ? (
                  <BarsChart data={skillsDist} horizontal height={320} />
                ) : (
                  <EmptyData title="No skills data" description="Upload resumes to build skills distribution." />
                )}
              </CardContent>
            </CardWrapper>
          )}
        </Grid>

        {/* Prediction distribution */}
        <Grid size={{ xs: 12, lg: 6 }}>
          {loading ? <ChartSkeleton /> : (
            <CardWrapper>
              <CardTitle title="Prediction Distribution" />
              <CardContent sx={{ pt: 1 }}>
                {predDist.length > 0 ? (
                  <DonutChart data={predDist} height={320} />
                ) : (
                  <EmptyData title="No prediction data" description="Run predictions to build prediction distribution." />
                )}
              </CardContent>
            </CardWrapper>
          )}
        </Grid>
      </Grid>
    </Box>
  );
}
