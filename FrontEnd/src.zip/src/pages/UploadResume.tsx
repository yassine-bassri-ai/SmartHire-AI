import { useState } from 'react';
import { Box, Grid2 as Grid, CardContent, Typography, Chip, Stack, Divider } from '@mui/material';
import { motion } from 'framer-motion';
import UploadFileRoundedIcon from '@mui/icons-material/UploadFileRounded';
import PictureAsPdfRoundedIcon from '@mui/icons-material/PictureAsPdfRounded';
import LanguageRoundedIcon from '@mui/icons-material/LanguageRounded';
import WorkHistoryRoundedIcon from '@mui/icons-material/WorkHistoryRounded';
import SchoolRoundedIcon from '@mui/icons-material/SchoolRounded';
import WorkspacePremiumRoundedIcon from '@mui/icons-material/WorkspacePremiumRounded';
import ArticleRoundedIcon from '@mui/icons-material/ArticleRounded';
import PageHeader, { CardWrapper, CardTitle } from '@/components/PageHeader';
import FileDropzone from '@/components/FileDropzone';
import InfoRow from '@/components/cards/InfoRow';
import ChipList from '@/components/common/ChipList';
import RawText from '@/components/common/RawText';
import EmptyData from '@/components/layout/EmptyData';
import UploadProgress from '@/components/upload/UploadProgress';
import { useUploadResume } from '@/hooks/useResume';
import type { Resume } from '@/utils/types';
import toast from 'react-hot-toast';

function ChipListInline({ items }: { items?: Array<string | number | null | undefined> }) {
  return <ChipList items={items} color="primary" />;
}

export default function UploadResume() {
  const [progress, setProgress] = useState(0);
  const [filename, setFilename] = useState<string | null>(null);
  const [parsed, setParsed] = useState<Resume | null>(null);
  const uploadMutation = useUploadResume();

  const handleUpload = async (file: File) => {
    setProgress(0);
    setParsed(null);
    try {
      const result = await uploadMutation.mutateAsync({
        file,
        onProgress: (pct) => setProgress(pct),
      });
      setParsed(result.resume);
      setFilename(result.resume.filename ?? file.name);
      toast.success('Resume uploaded & parsed successfully!');
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Upload failed');
    }
  };

  return (
    <Box>
      <PageHeader
        title="Upload Resume"
        subtitle="Upload a PDF resume to extract candidate information"
        icon={<UploadFileRoundedIcon />}
      />

      <Grid container spacing={3}>
        <Grid size={{ xs: 12, md: 6 }}>
          <CardWrapper>
            <CardTitle title="Drop your resume" />
            <CardContent sx={{ pt: 1 }}>
              <FileDropzone
                onFileSelected={handleUpload}
                accept={{ 'application/pdf': ['.pdf'] }}
                title="Drag & drop your PDF resume"
                subtitle="Only PDF files are supported · max 10MB"
                icon={<PictureAsPdfRoundedIcon sx={{ fontSize: 36 }} />}
                uploading={uploadMutation.isPending}
                progress={progress}
                uploadedFile={filename}
                onClear={() => { setFilename(null); setParsed(null); }}
                buttonText="Upload Resume"
              />
              <UploadProgress uploading={uploadMutation.isPending} progress={progress} label="Parsing resume…" />
            </CardContent>
          </CardWrapper>
        </Grid>

        <Grid size={{ xs: 12, md: 6 }}>
          <CardWrapper sx={{ height: '100%' }}>
            <CardTitle title="Parsed Resume Preview" />
            <CardContent sx={{ pt: 1 }}>
              {!parsed ? (
                <EmptyData
                  title="No resume parsed yet"
                  description="Upload a PDF resume to see extracted language, experience, skills, education, languages and certifications."
                  icon={<UploadFileRoundedIcon sx={{ fontSize: 40 }} />}
                />
              ) : (
                <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
                  <InfoRow icon={<ArticleRoundedIcon fontSize="small" />} label="Filename">
                    <Typography variant="body2" sx={{ fontWeight: 600 }}>{parsed.filename ?? '—'}</Typography>
                  </InfoRow>
                  <Divider />
                  <InfoRow icon={<LanguageRoundedIcon fontSize="small" />} label="Language">
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>{parsed.language ?? '—'}</Typography>
                  </InfoRow>
                  <Divider />
<InfoRow icon={<WorkHistoryRoundedIcon fontSize="small" />} label="Experience">
                    <Typography variant="body2" sx={{ fontWeight: 500 }}>{parsed.experience_years ?? 0} years</Typography>
                  </InfoRow>
                  <Divider />
                  <InfoRow icon={<WorkHistoryRoundedIcon fontSize="small" />} label="Skills">
                    <ChipListInline items={parsed.skills} />
                  </InfoRow>
                  <Divider />
                  <InfoRow icon={<SchoolRoundedIcon fontSize="small" />} label="Education">
                    <ChipListInline items={parsed.education} />
                  </InfoRow>
                  <Divider />
                  <InfoRow icon={<LanguageRoundedIcon fontSize="small" />} label="Languages">
                    <ChipListInline items={parsed.languages} />
                  </InfoRow>
                  <Divider />
                  <InfoRow icon={<WorkspacePremiumRoundedIcon fontSize="small" />} label="Certifications">
                    <ChipListInline items={parsed.certifications} />
                  </InfoRow>
                  <Divider />
                  <InfoRow icon={<ArticleRoundedIcon fontSize="small" />} label="Raw Text">
                    <RawText text={parsed.raw_text} maxHeight={220} />
                  </InfoRow>
                </motion.div>
              )}
            </CardContent>
          </CardWrapper>
        </Grid>
      </Grid>
    </Box>
  );
}
