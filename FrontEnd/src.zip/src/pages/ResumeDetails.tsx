import { useParams, useNavigate } from 'react-router-dom';
import {
  Box, Grid2 as Grid, CardContent, Typography, Divider, Chip, Stack, Button,
} from '@mui/material';
import ArrowBackRoundedIcon from '@mui/icons-material/ArrowBackRounded';
import PersonRoundedIcon from '@mui/icons-material/PersonRounded';
import LanguageRoundedIcon from '@mui/icons-material/LanguageRounded';
import WorkHistoryRoundedIcon from '@mui/icons-material/WorkHistoryRounded';
import SchoolRoundedIcon from '@mui/icons-material/SchoolRounded';
import WorkspacePremiumRoundedIcon from '@mui/icons-material/WorkspacePremiumRounded';
import ArticleRoundedIcon from '@mui/icons-material/ArticleRounded';
import InsightsRoundedIcon from '@mui/icons-material/InsightsRounded';
import PageHeader, { CardWrapper, CardTitle } from '@/components/PageHeader';
import InfoRow from '@/components/cards/InfoRow';
import ChipList from '@/components/common/ChipList';
import RawText from '@/components/common/RawText';
import EmptyData from '@/components/layout/EmptyData';
import { useResume } from '@/hooks/useResume';

export default function ResumeDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const resumeId = id ? Number(id) : undefined;
  const { data: resume, isLoading, isError } = useResume(resumeId);

  return (
    <Box>
      <PageHeader
        title="Resume Details"
        subtitle={`Detailed candidate information for resume #${id ?? '—'}`}
        icon={<ArticleRoundedIcon />}
        action={
          <Stack direction="row" spacing={1}>
            <Button variant="outlined" startIcon={<ArrowBackRoundedIcon />} onClick={() => navigate('/resumes')}>
              Back
            </Button>
            {resumeId && (
              <Button variant="contained" startIcon={<InsightsRoundedIcon />} onClick={() => navigate(`/predictions?resume=${resumeId}`)}>
                Run Prediction
              </Button>
            )}
          </Stack>
        }
      />

      {isLoading ? (
        <CardWrapper><CardContent><Box sx={{ p: 4 }}><EmptyData title="Loading resume…" description="Fetching parsed resume data from the backend." icon={<ArticleRoundedIcon />} /></Box></CardContent></CardWrapper>
      ) : isError || !resume ? (
        <CardWrapper><CardContent><EmptyData title="Resume not found" description="The resume could not be loaded. It may have been removed or the backend is offline." /></CardContent></CardWrapper>
      ) : (
        <Grid container spacing={3}>
          {/* Profile summary */}
          <Grid size={{ xs: 12, lg: 4 }}>
            <CardWrapper sx={{ height: '100%' }}>
              <CardTitle title="Candidate Information" action={<Chip label={`#${resume.id}`} size="small" />} />
              <CardContent sx={{ pt: 1 }}>
                <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', mb: 2 }}>
                  <Box sx={{ width: 76, height: 76, borderRadius: '50%', background: 'linear-gradient(135deg,#2563EB,#14B8A6)', display: 'flex', alignItems: 'center', justifyContent: 'center', mb: 1.5 }}>
                    <PersonRoundedIcon sx={{ color: '#fff', fontSize: 40 }} />
                  </Box>
                  <Typography variant="subtitle1" sx={{ fontWeight: 700, textAlign: 'center' }}>{resume.filename}</Typography>
                  <Typography variant="caption" sx={{ color: 'text.secondary', mt: 0.25 }}>
                    {resume.language ?? 'Unknown language'}
                  </Typography>
                </Box>
                <Divider />
                <InfoRow icon={<WorkHistoryRoundedIcon fontSize="small" />} label="Experience">
                  <Typography variant="body2" sx={{ fontWeight: 600 }}>{resume.experience_years ?? 0} years</Typography>
                </InfoRow>
                <Divider />
                <InfoRow icon={<LanguageRoundedIcon fontSize="small" />} label="Languages">
                  <ChipList items={resume.languages} color="default" />
                </InfoRow>
                {resume.parsing_status && (
                  <>
                    <Divider />
                    <InfoRow icon={<ArticleRoundedIcon fontSize="small" />} label="Parsing Status">
                      <Chip size="small" color="success" variant="outlined" label={resume.parsing_status} />
                    </InfoRow>
                  </>
                )}
                {resume.parsed_at && (
                  <>
                    <Divider />
                    <InfoRow icon={<ArticleRoundedIcon fontSize="small" />} label="Parsed At">
                      <Typography variant="body2">{new Date(resume.parsed_at).toLocaleString()}</Typography>
                    </InfoRow>
                  </>
                )}
              </CardContent>
            </CardWrapper>
          </Grid>

          {/* Parsed content */}
          <Grid size={{ xs: 12, lg: 8 }}>
            <CardWrapper>
              <CardTitle title="Parsed Resume Content" />
              <CardContent sx={{ pt: 1 }}>
                <InfoRow icon={<WorkHistoryRoundedIcon fontSize="small" />} label="Skills">
                  <ChipList items={resume.skills} color="primary" />
                </InfoRow>
                <Divider />
                <InfoRow icon={<SchoolRoundedIcon fontSize="small" />} label="Education">
                  <ChipList items={resume.education} color="secondary" />
                </InfoRow>
                <Divider />
                <InfoRow icon={<WorkspacePremiumRoundedIcon fontSize="small" />} label="Certifications">
                  <ChipList items={resume.certifications} color="warning" />
                </InfoRow>
                <Divider />
                <InfoRow icon={<ArticleRoundedIcon fontSize="small" />} label="Raw Text">
                  <RawText text={resume.raw_text} maxHeight={420} />
                </InfoRow>
              </CardContent>
            </CardWrapper>
          </Grid>
        </Grid>
      )}
    </Box>
  );
}
