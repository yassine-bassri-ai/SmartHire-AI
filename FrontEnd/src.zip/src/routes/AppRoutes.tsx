import { lazy, Suspense } from 'react';
import { Routes, Route } from 'react-router-dom';
import MainLayout from '@/layouts/MainLayout';
import Landing from '@/pages/Landing';
import { FullPageLoader } from '@/components/Skeletons';
import ErrorBoundary from '@/components/common/ErrorBoundary';

const Dashboard = lazy(() => import('@/pages/Dashboard'));
const UploadResume = lazy(() => import('@/pages/UploadResume'));
const UploadJob = lazy(() => import('@/pages/UploadJob'));
const Prediction = lazy(() => import('@/pages/Prediction'));
const CandidateRanking = lazy(() => import('@/pages/CandidateRanking'));
const Jobs = lazy(() => import('@/pages/Jobs'));
const JobDetails = lazy(() => import('@/pages/JobDetails'));
const Resumes = lazy(() => import('@/pages/Resumes'));
const ResumeDetails = lazy(() => import('@/pages/ResumeDetails'));
const Analytics = lazy(() => import('@/pages/Analytics'));
const NotFound = lazy(() => import('@/pages/NotFound'));

function withError(LazyComponent: React.LazyExoticComponent<React.ComponentType>) {
  return function Wrapped() {
    return (
      <ErrorBoundary>
        <Suspense fallback={<FullPageLoader />}>
          <LazyComponent />
        </Suspense>
      </ErrorBoundary>
    );
  };
}

const LazyDashboard = withError(Dashboard);
const LazyUploadResume = withError(UploadResume);
const LazyUploadJob = withError(UploadJob);
const LazyPrediction = withError(Prediction);
const LazyCandidateRanking = withError(CandidateRanking);
const LazyJobs = withError(Jobs);
const LazyJobDetails = withError(JobDetails);
const LazyResumes = withError(Resumes);
const LazyResumeDetails = withError(ResumeDetails);
const LazyAnalytics = withError(Analytics);
const LazyNotFound = withError(NotFound);

export default function AppRoutes() {
  return (
    <Routes>
      {/* Public landing page */}
      <Route path="/landing" element={<Landing />} />

      {/* App shell */}
      <Route
        path="/"
        element={<MainLayout />}
      >
        <Route index element={<LazyDashboard />} />
        <Route path="upload-resume" element={<LazyUploadResume />} />
        <Route path="upload-job" element={<LazyUploadJob />} />
        <Route path="predictions" element={<LazyPrediction />} />
        <Route path="candidate-ranking" element={<LazyCandidateRanking />} />
        <Route path="jobs" element={<LazyJobs />} />
        <Route path="jobs/:id" element={<LazyJobDetails />} />
        <Route path="resumes" element={<LazyResumes />} />
        <Route path="resumes/:id" element={<LazyResumeDetails />} />
        <Route path="analytics" element={<LazyAnalytics />} />
        <Route path="*" element={<LazyNotFound />} />
      </Route>
    </Routes>
  );
}
