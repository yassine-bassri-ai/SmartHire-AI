import api from './axios';
import { normalizeList, type Job, type JobUploadResponse } from '@/utils/types';

// POST /job/upload  (multipart/form-data, field: file)
export async function uploadJob(
  file: File,
  onProgress?: (pct: number) => void,
): Promise<JobUploadResponse> {
  const form = new FormData();
  form.append('file', file);
  const { data } = await api.post<JobUploadResponse>('/job/upload', form, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress: (e) => {
      if (e.total && onProgress) onProgress(Math.round((e.loaded / e.total) * 100));
    },
  });
  return data;
}

// GET /job  (returns all jobs)
export async function getJobs(): Promise<Job[]> {
  const { data } = await api.get('/job');
  return normalizeList<Job>(data);
}

// GET /job/all  (backend also exposes this endpoint)
export async function getJobsAll(): Promise<Job[]> {
  const { data } = await api.get('/job/all');
  return normalizeList<Job>(data);
}

// GET /job/{id}
export async function getJob(id: number): Promise<Job> {
  const { data } = await api.get(`/job/${id}`);
  return data;
}

// DELETE /job/{id}  (best-effort)
export async function deleteJob(id: number): Promise<void> {
  await api.delete(`/job/${id}`);
}
