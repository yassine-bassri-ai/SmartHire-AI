import axios, { type AxiosInstance, type AxiosError } from 'axios';

const BASE_URL: string = import.meta.env.VITE_API_URL ?? 'http://localhost:8000';

// Central axios instance for the SmartHire AI backend (FastAPI).
export const api: AxiosInstance = axios.create({
  baseURL: BASE_URL,
  timeout: 60000,
  headers: { 'Content-Type': 'application/json' },
});

// Attach auth token if present (future-proofed; backend is currently open).
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('smarthire-token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// Normalize backend errors into a readable message.
api.interceptors.response.use(
  (response) => response,
  (error: AxiosError<{ detail?: string; message?: string }>) => {
    const raw = error?.response?.data;
    const detail = typeof raw?.detail === 'string' ? raw.detail : undefined;
    const message =
      detail ||
      raw?.message ||
      error?.message ||
      'Unexpected error occurred. Please try again.';
    return Promise.reject(new Error(message));
  },
);

export const API_BASE_URL = BASE_URL;
export default api;
