import api from './axios';
import { normalizeList, type Prediction, type PredictionResponse, type PreviousPredictionsResponse } from '@/utils/types';

// POST /predictions/{resume_id}  (run predictions)
export async function runPrediction(resumeId: number): Promise<Prediction[]> {
  const { data } = await api.post<PredictionResponse>(`/predictions/${resumeId}`);
  return normalizeList<Prediction>(data.best_jobs ?? data);
}

// GET /predictions/{resume_id}  (previous predictions)
export async function getPredictions(resumeId: number): Promise<Prediction[]> {
  const { data } = await api.get<PreviousPredictionsResponse>(`/predictions/${resumeId}`);
  return normalizeList<Prediction>(data.top_matches ?? data);
}
