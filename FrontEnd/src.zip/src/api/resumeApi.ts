import api from './axios';
import { normalizeList, type Resume, type ResumeUploadResponse } from '@/utils/types';

// POST /resume/upload  (multipart/form-data, field: file)
export async function uploadResume(
  file: File,
  onProgress?: (pct: number) => void,
): Promise<ResumeUploadResponse> {
  const form = new FormData();
  form.append('file', file);
  const { data } = await api.post<ResumeUploadResponse>('/resume/upload', form, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress: (e) => {
      if (e.total && onProgress) onProgress(Math.round((e.loaded / e.total) * 100));
    },
  });
  return data;
}

// GET /resume  (returns all resumes)
export async function getResumes(): Promise<Resume[]> {
  const { data } = await api.get('/resume');
  return normalizeList<Resume>(data);
}

// GET /resume/{id}
export async function getResume(id: number): Promise<Resume> {
  const { data } = await api.get(`/resume/${id}`);
  return data;
}

// DELETE /resume/{id}  (best-effort; backend may not expose delete)
export async function deleteResume(id: number): Promise<void> {
  await api.delete(`/resume/${id}`);
}
